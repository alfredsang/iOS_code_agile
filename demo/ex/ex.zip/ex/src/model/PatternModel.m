//
//  PatternModel.m
//  ex
//
//  Created by minglq on 12-8-7.
//
//

#import "PatternModel.h"

@implementation PatternModel

@end
