//
//  PatternModel.h
//  ex
//
//  Created by minglq on 12-8-7.
//
//

#import <Foundation/Foundation.h>


@interface PatternModel : NSObject

@end
