//
//  SummaryViewController.h
//  ex
//
//  Created by alfred sang on 12-8-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SummaryViewController : UIViewController


@property(nonatomic,retain,readwrite) id delegate;

-(IBAction)viewShiti:(id)sender;


@end
